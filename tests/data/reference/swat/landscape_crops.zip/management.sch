management.sch: written by SWAT+ editor v4.0.2 on 2026-10-16 16:03 for SWAT+ 62.0
name                                       numb_ops  numb_auto            op_typ       mon       day        hu_sch          op_data1          op_data2      op_data3  
corn_rot                          0          1  
                                                   pl_hv_summer1   corn  
wwht_rot                          0          1  
                                                   pl_hv_winter1   wwht  
